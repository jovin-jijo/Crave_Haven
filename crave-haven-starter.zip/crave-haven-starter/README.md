# Crave Haven

Starter structure for the Crave Haven cooking website.

This project is designed to be adapted from the existing T3M1N4L Astro/Bun foundation without copying its UI or visual design.

## Structure

- `public/images/hero/` — put the nature hero image here as `nature.jpg`
- `public/images/recipes/` — recipe images
- `public/images/blog/` — blog images
- `public/images/logo/` — Crave Haven visual assets
- `src/components/` — reusable UI components
- `src/data/` — recipe/blog data
- `src/layouts/` — page layouts
- `src/pages/` — routes
- `src/styles/` — global design system

## Hero behavior

The nature image is used only for the first viewport. It fills the first screen with `cover`, then completely ends when the user scrolls into the rest of the page.

## Existing repo

Copy these files into the corresponding locations in your existing Astro/Bun repo. Keep that repo's working Astro/Bun/TypeScript/SCSS setup; this starter does not attempt to reproduce its UI.
