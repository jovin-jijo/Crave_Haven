export const recipes = [
  {
    title: "Sample Recipe",
    category: "Dinner",
    image: "/images/recipes/sample.jpg",
    slug: "sample-recipe",
  },
];
