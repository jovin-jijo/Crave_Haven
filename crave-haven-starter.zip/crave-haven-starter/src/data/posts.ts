export const posts = [
  {
    title: "Welcome to Crave Haven",
    excerpt: "A place for recipes, cooking ideas, and things worth craving.",
    slug: "welcome-to-crave-haven",
  },
];
